#pragma once

void ctrlCHandler(int sig_num);